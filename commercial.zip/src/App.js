import React from 'react';
import Product from './Product'; 
import './commercial.css';

const App = () => {
  const products = [
    {
      "title": "Brown eggs",
      "type": "dairy",
      "description": "Raw organic brown eggs in a basket",
      "url": "https://images.unsplash.com/photo-1701252776710-d81bfd7a5806?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 28.1,
      "rating": 4
    },
    {
      "title": "Sweet fresh strawberry",
      "type": "fruit",
      "description": "Sweet fresh strawberry on wooden table",
      "url": "https://plus.unsplash.com/premium_photo-1683892045066-e8f1e1d09f74?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 29.45,
      "rating": 4
    },
    {
      "title": "Organic apples",
      "type": "fruit",
      "description": "Organic apples with the leaf on wooden table",
      "url": "https://plus.unsplash.com/premium_photo-1669557209063-00212df37810?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 45.3,
      "rating": 5
    },
    {
      "title": "Avocado toast",
      "type": "dairy",
      "description": "Avocado toast with cherry tomatoes and microgreens",
      "url": "https://images.unsplash.com/photo-1632217471220-a661da2ae319?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3Dhttps://images.unsplash.com/photo-1628556820645-63ba5f90e6a2?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 12.75,
      "rating": 5
    },
    {
      "title": "Healthy breakfast",
      "type": "dairy",
      "description": "Healthy breakfast set with strawberry and honey",
      "url": "https://images.unsplash.com/photo-1568926903943-448fbbe46161?q=80&w=1889&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 19.99,
      "rating": 4.5
    },
    {
      "title": "Fresh orange juice",
      "type": "drink",
      "description": "Freshly squeezed orange juice in a glass",
      "url": "https://images.unsplash.com/photo-1600271886742-f049cd451bba?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 8.99,
      "rating": 4
    },
    {
      "title": "Assorted vegetables",
      "type": "vegetables",
      "description": "Assorted fresh vegetables on the wooden table",
      "url": "https://plus.unsplash.com/premium_photo-1664302148512-ddea30cd2a92?q=80&w=1769&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 35.6,
      "rating": 4.5
    },
    {
      "title": "Classic High Heels",
      "type": "shoe",
      "description": "Black classic high heels for formal occasions",
      "url": "https://images.unsplash.com/photo-1523464771852-de9293765f7a?q=80&w=1771&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 59.99,
      "rating": 4.3
    },
    {
      "title": "Running Shoes",
      "type": "shoe",
      "description": "Comfortable running shoes for all terrains ",
      "url": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      "price": 79.99,
      "rating": 4
    },
    
  ];

  return (
    <div className="App">
      <h1>Welcome to E-commerce Store</h1>
      <div className="products">
        {products.map((product, index) => (
          <Product
            key={index}
            title={product.title}
            type={product.type}
            description={product.description}
            url={product.url}
            price={product.price}
            rating={product.rating}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
