import React, { useState } from 'react';
import './commercial.css';

const Product = ({ title, type, description, url, price, rating }) => {
  const [liked, setLiked] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [showDescription, setShowDescription] = useState(false);

  const handleLike = () => {
    setLiked(!liked);
  };

  const handleAddToCart = () => {
    console.log('Adding to cart:', title); 
    setAddedToCart(true);
    alert('Item added to cart');
  };

  const handleShare = () => {
    alert('Product shared');
  };

  const handlePurchase = () => {
    alert('Product purchased');
  };

  const toggleDescription = () => {
    setShowDescription(true);
  };

  return (
    <div className="product">
      <h3>{title}</h3>
      {showDescription ? (
        <>
          <p>{description}</p>
          <button onClick={() => setShowDescription(false)}>Hide Description</button>
        </>
      ) : (
        <button onClick={toggleDescription}>Description</button>
      )}
      <p>Type: {type}</p>
      <p>Price: ${price}</p>
      <p>Rating: {rating}</p>
      <button className={`heart-button ${liked ? 'liked' : ''}`} onClick={handleLike}>
        {liked ? "UNLIKE" : "LIKE"}
      </button>
      <button onClick={handleShare}>
        SHARE
      </button>
      <button onClick={handleAddToCart}>
        ADD TO CART
      </button>
      <button onClick={handlePurchase}>PURCHASE</button>
    </div>
  );
};

export default Product;








